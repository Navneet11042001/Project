<?php
include('common/mainheader.php')
?>
    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section position-relative" >
      <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
          <li data-target="#customCarousel1" data-slide-to="1"></li>
          <li data-target="#customCarousel1" data-slide-to="2"></li>
          <li data-target="#customCarousel1" data-slide-to="3"></li>
        </ol>
        <div class="carousel-inner" >
          <div class="carousel-item active">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                    Pest <br />
                    Insight Hub
                  </h2>
                </div>
                
              </div>
              <div class="care_detail">
                <a href="contact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                    We will take <br />
                    Care of <br />
                    your Crops
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Pest <br />
                  Insight Hub
                  </h2>
                </div>
               
              </div>
              <div class="care_detail">
                <a href="contact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    your Crops
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Pest <br />
                  Insight Hub
                  </h2>
                </div>
                
              </div>
              <div class="care_detail">
                <a href="contact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    your Crops
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Pest <br />
                  Insight Hub
                  </h2>
                </div>
               
              </div>
              <div class="care_detail">
                <a href="contact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    your Crops
                  </h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- service section -->

  <section class="service_section ">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/grains.png" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                Grains
              </h4>
              <p>
              Grain is the harvested seed of grasses such as wheat, oats, rice, and corn.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box ">
            <div class="img-box">
              <img src="images/horticulture.jpeg" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                Horticulture
              </h4>
              <p>
                Available, but the majority have suffered alteration in some form, by injected
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/irrigated.png" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                Irrigated Crops
              </h4>
              <p>
                Available, but the majority have suffered alteration in some form, by injected
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/production.png" alt="" />
            </div>
            <div class="detail-box">
              <h4>
              Production
              </h4>
              <p>
                Available, but the majority have suffered alteration in some form, by injected
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end service section -->

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container-fluid">
      <div class="box">
        <div class="img-box">
          <img src="images/about3.jpeg" alt="" />
        </div>
        <div class="detail-box">
          <h2>
            Found New Pests?
          </h2>
          <p>
            Here, You can submit the details of the pest found.
            You can upload the picture of that pest.
          </p>
          <a href="foundpest.php">
            <span>
              Read More
            </span>
            <hr />
          </a><br/><br/>
          <h2>
            Here are Some Government Schemes.
          </h2>
          <p>
            Here, we provide the Details of Government schemes, Run by the Government of India for the Sake of wellbeing of the Farmers.
          </p>
          <a href="governmentschemes.php">
            <span>
              Read More
            </span>
            <hr />
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- we have section -->

  <section class="wehave_section">
    <div class="container-fluid">
      <div class="box">
        <div class="detail-box">
          <h2>
            We Have Good <br />
            on show details of pests
          </h2>
          <p>
            We provide you the deep information on the Pests, Like their Nature,their Diet, the Temperature suitable for them and the kind of crops they Harm.
          </p>
          <a href="why.php">
            <span>
              Read More
            </span>
            <hr />
          </a>
        </div>
        <div class="img-box">
          <img src="images/about.jpeg" alt="" />
        </div>
      </div>
    </div>
  </section>

  <!-- end we have section -->

  <!-- why section -->

    <!-- why section -->

    <section class="why_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Why Choose Us
        </h2>
        <p>
        By sharing science-based knowledge about crop health, Anti Pesto helps smallholder farmers to grow more and lose less, increase their incomes and improve their livelihoods
        </p>
      </div>
      <div class="why_container">
        <div class="box">
          <div class="img-box">
            <img src="images/challenge2.png" alt="" style="height:80px; width:80px;"/>
          </div>
          <div class="detail-box">
            <h5>
            Deep Insights
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/variety2.png" alt="" style="height:100px; width:100px;" />
          </div>
          <div class="detail-box">
            <h5>
            Diversification
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/why3.png" alt="" />
          </div>
          <div class="detail-box">
            <h5>
            Crop Rotation Info
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/why4.png" alt="" />
          </div>
          <div class="detail-box">
            <h5>
            Integrated Pest Management (IPM)
            </h5>
            
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end why section -->

  <!-- end why section -->

  <!-- team section -->

  <section class="team_section">
    <div class="container-fluid">
      <div class="heading_container">
       <h2>
          Our Team
        </h2>
        <p>
         Navneet Chaudhary   ||   Madhav Sharma
        </p>
      </div>
      <div class="carousel-wrap ">
        <div class="owl-carousel team_carousel">
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/nav2.jpeg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Navneet Chaudhary
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/madhav.jpg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Madhav Sharma
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/madhavsharmawd">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end team section -->

  <!-- contact section -->

  <section class="contact_section layout_padding-top">
    <div class="container">
      <div class="row">
        <div class="col-md-8 mx-auto">
          <div class="contact-form">
            <div class="heading_container">
              <h2>
                Any Quaries / Suggestion
              </h2>
            </div>
            <form action="query.php" method="post">
              <input value="<?= $_SESSION['name'];?>"type="text" name="name" placeholder="Full name ">
              <div class="top_input">
                <input value="<?= $_SESSION['email'];?>"type="email" name="email" placeholder="Email">
                <input  type="tel" name="number" placeholder="Phone Number">
              </div>
              <input type="text" name="message" placeholder="Message" class="message_input">
              <div class="btn-box">
                <button type="submit">Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end contact section -->

  <!-- client section -->

  <section class="client_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Research Labs 
        </h2>
      </div>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="box">
              <div class="img-box">
                <img src="images/lab1.1.jpeg" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                    ICAR - Indian Agricultural Research Institute
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                The Indian Council of Agricultural Research (ICAR) is an autonomous organisation under the Department of Agricultural Research and Education (DARE), Ministry of Agriculture and Farmers Welfare , Government of India. Formerly known as Imperial Council of Agricultural Research, it was established on 16 July 1929 as a registered society under the Societies Registration Act, 1860 in pursuance of the report of the Royal Commission on Agriculture. The ICAR has its headquarters at New Delhi.
              </p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="img-box">
                <img src="images/lab2.jpeg" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                    Indian Agricultural Research Institute Gate No.1
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                To explore new frontiers of science and develop human resources to provide the leadership in technology development and policy guidance for vibrant and resilient agriculture, which should be productive, eco-friendly, sustainable, economically profitable and socially equitable.
                </p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="img-box">
                <img src="images/lab3.png" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                      Indian Council of Agriculture Research
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                The Indian Council of Agricultural Research (ICAR) is an autonomous organisation under the Department of Agricultural Research and Education (DARE), Ministry of Agriculture and Farmers Welfare , Government of India. Formerly known as Imperial Council of Agricultural Research, it was established on 16 July 1929 as a registered society under the Societies Registration Act, 1860 in pursuance of the report of the Royal Commission on Agriculture. The ICAR has its headquarters at New Delhi. 
                </p>
              </div>
            </div>
          </div>
        </div>
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
      </div>
    </div>
  </section>

  <!-- end client section -->

  <!-- info section -->

 <?php
 include('common/footer.php');
 ?>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>

</body>

</html>