<?php
 
include('common/connection.php');
 // print_r($_POST);die();
if(isset($_POST['username'])){

     $adminname = $_POST['username'];
     $password = $_POST['pswrd'];

     $sql ="select * from admin where email='".$_POST['username']."' && password='".$_POST['pswrd']."'";

   
     $result =mysqli_query($conn,$sql);

     if(mysqli_num_rows($result) > 0){

         while($row = $result->fetch_assoc()) {

 
       session_start();
         $_SESSION['id'] = $row['id'];
          $_SESSION['name'] = $row['name'];
          $_SESSION['email'] = $row['email'];
        header('Location:admindetails.php');
      

    }
     }
     else{
      
        echo "<script>
      window.location.href = 'admin.php';
      alert('you are not a admin...');
</script>";
     }
}
?>