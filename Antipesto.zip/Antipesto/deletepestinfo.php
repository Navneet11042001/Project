<?php
include('common/connection.php');


$id = $_REQUEST['id'];

$sql="delete from pests where id = ".$id;

mysqli_query($conn,$sql);
header('Location:pest.php');
?>