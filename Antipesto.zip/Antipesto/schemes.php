<html>
    <head>
        <style>
            body 
{
  font-family:sans-serif; 
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  color:whitesmoke;
}

h1{
    text-align: center;
}


form{
    width:50rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
}
form input{
    color:black;
}
form select{
    color:black;
    font-size:30px;
}

input[type=file],input[type=text], input[type=name],input[type=date]{
    width: 100%;
    margin: 10px 0;
    border-radius: 15px;
    padding: 5px 18px;
    box-sizing: border-box;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 15px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
            </style>
</head>
<body>
<?php 
include('common/header.php');
?>
<form action="uploadschemedetails.php" method="post" enctype="multipart/form-data" style="margin-top: 30px;">
    <div class="imgcontainer">
    <img src="images/logo.png" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>UPLOAD SCHEMES  </h3>
            <p><?= $_SESSION['email'];?></p>
            <p>NOTE: upload schemes</p>
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Password -->
            <label for="text">Title</label>
            <input value="" type="text" placeholder="Enter Title" name="title" required>
            <label for="file" class="up">Upload File</label>
            <input type="file" placeholder="upload file" required class="img" name="img" style="color:white;">
            <label for="date">Publish Date</label>
            <input type="date" placeholder="Enter Date" name="date" required>
            <label for="text">Details</label>
            <input value="" type="text" placeholder="Enter Details" name="details" required>
            

            <!-- Submit button -->
            <button type="submit" name="submit">send</button>

        </div>

    </form>

</body>
</html>
