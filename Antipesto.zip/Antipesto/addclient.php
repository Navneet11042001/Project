<?php
include('common/connection.php');



	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $username = $_POST['username'];
        $number = $_POST['number'];
        $address = $_POST['address'];
        $password = $_POST['pswrd'];
        $age = $_POST['age'];

        move_uploaded_file($tempname, $folder);
        $sql="insert into clientlogin(name,email,number,age,address,password) values('".$name."','$username','$number','$age','$address','$password')";

       

        if(mysqli_query($conn,$sql)){
            echo "<script>
      window.location.href = 'logins.php';
      alert('new record inserted successfully..')</script>";
            
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>