<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $type = $_POST['type'];
        $symptoms = $_POST['symptoms'];
        $bionomics = $_POST['bionomics'];
        $solution = $_POST['solution'];

        $pid=$_POST['pid'];

          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;
        move_uploaded_file($tempname, $folder);
        $sql="UPDATE pests SET name='".$name."',image='$img',symptoms='$symptoms',Bionomics='$bionomics',solution='".$solution."',type='$type' WHERE id = '$pid'";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'pest.php';
          alert('update successfully');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>