<?php
include('common/connection.php');


$id = $_REQUEST['id'];

$sql="delete from foundpest where id = ".$id;

mysqli_query($conn,$sql);
header('Location:newpest.php');
?>