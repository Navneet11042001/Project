<?php
include('common/connection.php');


$id = $_REQUEST['id'];

$sql="delete from query where id = ".$id;

mysqli_query($conn,$sql);
header('Location:queryinfo.php');
?>