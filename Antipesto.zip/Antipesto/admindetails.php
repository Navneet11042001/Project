
<?php 
include('common/header.php');
?>
<style>
   input{
    border-color:black;
    border-radius:7px;
  }
  button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .navbar-b{
    margin-left:6%;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Admins</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value=''type="number" placeholder=" ID" name="ide" id="ide">
    <input value='' type="name" placeholder="Select Name" name="name" id="name">
      <input value='' type="address" placeholder="Select Address" name="color" id="color">
      
    
    </div>
    <div class="button-b">
        <button type="submit">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>

        <th>Name</th>

        <th>Email</th>

        <th>Number</th>
        
        <th>Address</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $ide = filter_input(INPUT_POST,'ide', FILTER_SANITIZE_STRING);
 if($ide=='')
 {
  $sql = "SELECT * FROM admin where address like '%$color%' and name like '%$name%'";
 }
 else{
  $sql = "SELECT * FROM admin where address like '%$color%' and name like '%$name%' and id = '$ide'";
 }

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["id"];?></td>
        <td><?php echo $row["name"];?></td>
        <td><?php echo $row["email"];?></td>
        <td><?php echo $row["number"];?></td>
        <td><?php echo $row["address"];?></td>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
