<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $email = $_POST['email'];
        $crop = $_POST['crop'];
        $location = $_POST['location'];
        $message = $_POST['message'];

          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;

        move_uploaded_file($tempname, $folder);
        $sql="insert into foundpest(name,image,email,crop,location,message) values('".$name."','$img','$email','$crop','$location','$message')";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'foundpest.php';
          alert('your record inserted..');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>