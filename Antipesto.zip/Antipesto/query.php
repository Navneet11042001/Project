<?php
include('common/connection.php');



	if(isset($_POST['email'])){

  		$name = $_POST['name'];
        $email = $_POST['email'];
        $number = $_POST['number'];
        $message = $_POST['message'];

        move_uploaded_file($tempname, $folder);
        $sql="insert into query(name,email,number,message) values('".$name."','$email','$number','$message')";

       

        if(mysqli_query($conn,$sql)){
            echo "<script>
          window.location.href = 'home.php';
          alert('new record inserted..');
    </script>";
           
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>