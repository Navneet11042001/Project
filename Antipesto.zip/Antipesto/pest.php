
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
  }
  .button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Upload Pests Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input type="text" placeholder="Enter Name" name="name" id="name">
      <input type="address" placeholder="Enter Crop" name="color" id="color">
    
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
      <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Crop</th>
        <th>Symptoms</th>
        <th>Bionomics</th>
        <th>Solution</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 if($color == '' && $name=='' )
 {
  $sql = "SELECT * FROM pests";
 }
 else if($name=='')
 {
  $sql = "SELECT * FROM pests where type like '%$color%'";
 }
 else if($color=='')
 {
  $sql = "SELECT * FROM pests where name like '$name%'";
 }
  else {
  $sql = "SELECT * FROM pests where type like '%$color%' and name like '$name%'";
 }

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["id"];?></td>
        <td> <img src="images/<?php echo $row['image'];?>" style="width:100px"></td>
        <td><?php echo $row["name"];?></td>
        <td><?php echo $row["type"];?></td>
        <td><?php echo $row["symptoms"];?></td>
        <td><?php echo $row["Bionomics"];?></td>
        <td><?php echo $row["solution"];?></td>
        <td><a href="deletepestinfo.php?id=<?php echo $row['id'];?>"><button>Delete</button></a>
        <a href="editpestdetails.php?id=<?php echo $row['id'];?>"><button>Edit</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
