<?php 

include('connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:logins.php');
}
 ?>

<head>
  <title>ANTI PESTO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  container-e li a{
	color: black;
  }
  </style>
</head>
<header>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
	<a href="queryinfo.php" style="font-size: 20px; ;color: white; text-decoration:none;"><img src="images/logo.png" alt="NGO logo" style="border-radius: 25px; height:50px; width: 50px; margin-top:5px"/>  ANTI PESTO</a>
    </div>
    <ul class="nav navbar-nav">
      <li class=""style="margin-left: 20px;"><a href="admindetails.php">Admins info</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Client side <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="userinfo.php">User info</a></li>
          <li><a href="queryinfo.php">Query</a></li>
          <li><a href="newpest.php">New Pests</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Pests <span class="caret"></span></a>
        <ul class="dropdown-menu">
        <li><a href="pest.php">pest Info</a></li>
          <li><a href="newpest.php">New Pests</a></li>
          <li><a href="uploadpests.php">upload pest details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Schemes <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="schemesinfo.php">Schemes info</a></li>
          <li><a href="schemes.php">Upload Schemes</a></li>
        </ul>
      </li>
    </ul>
      </li>
     
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
  </div>
</nav>
<header>
  