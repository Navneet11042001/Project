<?php
include('common/mainheader.php');
?>
<style>
  <style>
@media screen and (max-width: 600px) {
  form{
    width: 25rem;
  }

}

@media screen and (max-width: 400px) {
  form{
    width: 20rem;
  }
}
body 
{
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  
}

h1{
    text-align: center;
}


.form-p{
    width:35rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
    margin-bottom:20px;
}
.select-p{
  font-size:30px;
}

input[type=file],input[type=text], input[type=name]{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 10px 18px;
    box-sizing: border-box;
  }
  select{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 15px 20px;
    box-sizing: border-box;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 5px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }

  /* Media queries for the responsiveness of the page */
  @media screen and (max-width: 600px) {
    form{
      width: 25rem;
    }
  }
  
  @media screen and (max-width: 400px) {
    form{
      width: 20rem;
    }
  }

  /* image logo */
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
.col-md-4{
  width:10px;
}
  </style>
</style>
    <form action="foundnewpest.php" method="post" enctype="multipart/form-data" style="margin-top: 30px;" class="form-p">
    <div class="imgcontainer">
    <img src="images/logo.png" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Found New Pests </h3>
            <p><?= $_SESSION['email'];?></p>
            <p>NOTE: Enter Found New Pests Details</p>
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Password -->
            <label for="text">Your Email / आपका ईमेल</label>
            <input value="<?= $_SESSION['email'];?>" type="text" placeholder="Enter Your Name" name="email" required>
            <label for="text">Name / नाम</label>
            <input value="<?= $_SESSION['name'];?>" type="text" placeholder="Enter Your Name" name="name" required>
            <label for="image">New pests Image / कीट छवि</label>
            <input type="file" placeholder="upload image" required class="img" name="img">
            <label for="text">Select Crop / फसल का चयन करें</label>
            <select id="crop" name="crop" class="select-p">
            <option value="crop">Select Crop</option>
            <option value="wheat">गेहूं / Wheat</option>
            <option value="barley">जौ / Barley</option>
            <option value="canola">कैनोला / canola</option>
            <option value="lupins">ल्यूपिन / Lupins</option>
            <option value="oats">जई / Oats</option>
            <option value="cotton">कपास / cotton</option>
            <option value="sugarcane">गन्ना / sugarcane</option>
            <option value="rice">चावल / Rice</option>
            </select>
            <label for="text">Pests Location / कीटों का स्थान</label>
            <input type="text" placeholder="Enter Found Pests Address" name="location" required>
            <label for="text">Message / संदेश</label>
            <input type="text" placeholder="Enter Descripton about Pests" name="message" required>


            <!-- Submit button -->
            <button type="submit" name="submit">send</button>
            <p class="register">Go Back-><a href="home.php">HOME</a></p>

        </div>

    </form>
    <?php
include('common/footer.php');
?>
    <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
  </body>
</html>